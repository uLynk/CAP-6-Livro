package com.example.listadecompras

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import	android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val list_view_produtos = findViewById<ListView>(R.id.list_view_produtos)
        val btn_inserir = findViewById<Button>(R.id.btn_inserir)
        val txt_produto = findViewById<EditText>(R.id.txt_produto)

        val produtosAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)

        list_view_produtos.adapter	=	produtosAdapter

        btn_inserir.setOnClickListener {
            val produto = txt_produto.text.toString();

            if (produto.isNotEmpty()) {
                produtosAdapter.add(produto);
                txt_produto.text.clear()
            } else {
                txt_produto.error = "Preencha um valor"
            }


        }

        list_view_produtos.setOnItemLongClickListener{ adaptiveView: AdapterView<*>, view: View, position: Int, id: Long ->
            val item = produtosAdapter.getItem(position);
            produtosAdapter.remove(item);
            true;
        }

    }
}